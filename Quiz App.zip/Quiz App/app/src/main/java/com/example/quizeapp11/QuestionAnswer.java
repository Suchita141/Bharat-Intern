package com.example.quizeapp11;

public class QuestionAnswer {
    public static String question[] ={
            "Who is the prime minister of India?",
            "Which animal is know as ship of the desert?",
            "How many days are there in a week?",
            "How many hours are there in a day?"
    };

    public static String choices[][] = {
            {"Narendra modi","Murmu","obama","Nehru"},
            {"Camel","Donkey","Dog","Cat"},
            {"12 days","7 days","15 days","6 days"},
            {"12 hours","24 hours","36 hours","45 hours"}
    };

    public static String correctAnswers[] = {
            "Narendra modi",
            "Camel",
            "7 days",
            "24 hours"
    };
}
